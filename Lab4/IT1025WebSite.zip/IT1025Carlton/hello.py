#Carlton Radivoyevitch 06/10/20 code by
#"Automate the Boring Stuff with Python."
print('Hello World!')
print('What is your name?')
myName= input()
print('It is good to meet you, '+ myName)
print(len(myName))
print('What is your age?')
myAge= input()
print ('you will be' +str(int(myAge) + 1) + 'in a year.')
      
